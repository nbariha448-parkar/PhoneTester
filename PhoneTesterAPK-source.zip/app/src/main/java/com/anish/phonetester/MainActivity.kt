package com.anish.phonetester

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var eventCount = 0L
    private var mode = "SMS"
    private lateinit var status: TextView
    private lateinit var counter: TextView
    private lateinit var log: TextView
    private lateinit var testLabel: EditText

    // 20x demo speed: one local simulation event every 50 ms.
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            eventCount++
            val label = testLabel.text.toString().ifBlank { "LOCAL TEST" }
            val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
            log.append("[$time] SIMULATED $mode • $label • #$eventCount\n")
            counter.text = "Simulated events: $eventCount"
            handler.postDelayed(this, 50L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }

        fun heading(text: String, size: Float = 22f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFF172033.toInt())
                if (size >= 20f) setTypeface(null, Typeface.BOLD)
                setPadding(0, 8, 0, 12)
            }

        root.addView(heading("ANISH EXPLOITS", 24f))
        root.addView(heading("PHONE TESTER • LOCAL SIMULATION", 14f))

        val warning = heading(
            "Safe demo only: this app does not send SMS, place calls, access contacts, or use mobile-network services.",
            14f
        )
        warning.setTextColor(0xFF9A3412.toInt())
        root.addView(warning)

        testLabel = EditText(this).apply {
            hint = "Optional test label (not a phone number)"
            singleLine = true
            textSize = 16f
        }
        root.addView(testLabel, matchParams())

        status = heading("Status: STOPPED", 16f)
        root.addView(status)
        counter = heading("Simulated events: 0", 18f)
        root.addView(counter)

        val sms = makeButton("Start SMS simulation") { start("SMS") }
        val call = makeButton("Start call simulation") { start("CALL") }
        val stop = makeButton("STOP") { stopSimulation() }
        val clear = makeButton("Clear log") {
            log.text = ""
            eventCount = 0L
            counter.text = "Simulated events: 0"
        }

        root.addView(sms, matchParams())
        root.addView(call, matchParams())
        root.addView(stop, matchParams())
        root.addView(clear, matchParams())

        root.addView(heading("Live local activity log", 17f))
        log = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFF263238.toInt())
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
            text = "Ready. Choose a simulation mode.\n"
        }
        val logScroll = ScrollView(this).apply {
            addView(log)
        }
        root.addView(logScroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun matchParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun makeButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 15f
            setOnClickListener { action() }
        }

    private fun start(selectedMode: String) {
        stopSimulation()
        mode = selectedMode
        running = true
        status.text = "Status: RUNNING • $mode • 20x demo speed"
        log.append("\n--- Started $mode simulation ---\n")
        handler.post(tick)
    }

    private fun stopSimulation() {
        running = false
        handler.removeCallbacks(tick)
        if (::status.isInitialized) status.text = "Status: STOPPED"
    }

    override fun onDestroy() {
        stopSimulation()
        super.onDestroy()
    }
}
